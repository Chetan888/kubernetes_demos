const batchJob = setTimeout(()=>console.log(`Completed the Job - ${new Date()}`), 5000 );

console.log(`Starting the Batch Job - ${new Date()}`);
